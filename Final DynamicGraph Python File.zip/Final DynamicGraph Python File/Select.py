import sys
from PyQt5.QtWidgets import *
from PyQt5.QtGui import QIcon, QPixmap
from Playlist_DynamicGraph import *
from Input import*
from Delete import*
from Output_WhatKind import*


#파일 불러오기
f_artist = open("f_artist.text", 'rt')
f_culture = open("f_culture.text", 'rt')
f_genre = open("f_genre.text", 'rt')
f_year = open("f_year.text", 'rt')

#파일에 저장된 정보를 그래프에 업로드
#프로그램이 꺼졌을때도 기록된 정보들을 잃지 않기 위함
line1 = f_artist.readlines()
for str_A in line1:
    str_Akey = str_A.split(':')[0]
    str_Avalue = str_A.split(':')[1]
    n_Artist[str_Akey] = str_Avalue

line2 = f_year.readlines()
for str_Y in line2:
    str_Ykey = str_Y.split(':')[0]
    str_Yvalue = str_Y.split(':')[1]
    n_Year[str_Ykey] = str_Yvalue

line3 = f_genre.readlines()
for str_G in line3:
    str_Gkey = str_G.split(':')[0]
    str_Gvalue = str_G.split(':')[1]
    n_Genre[str_Gkey] = str_Gvalue

line4 = f_culture.readlines()
for str_C in line4:
    str_Ckey = str_C.split(':')[0]
    str_Cvalue = str_C.split(':')[1]
    n_Culture[str_Ckey] = str_Cvalue


#기능 선택
class Select(QWidget):
    def __init__(self):
        super().__init__()
        self.title = 'Artwork Playlist'
        self.initUI()


    def initUI(self):
        self.setWindowTitle(self.title)
        self.setGeometry(0, 0, 300, 300)

        # 배경 이미지
        label = QLabel(self)
        pixmap = QPixmap('pallette')
        label.setPixmap(pixmap)
        self.resize(pixmap.width(), pixmap.height())

        groupBox = QGroupBox("ArtWork Playlist", self)
        groupBox.move(10, 10)
        groupBox.resize(180, 120)

        #선택 항목
        self.radio1 = QRadioButton("Play", self)
        self.radio1.move(20, 40)
        self.radio1.clicked.connect(self.radioButtonClicked)

        self.radio2 = QRadioButton("Add on Playlist", self)
        self.radio2.move(20, 70)
        self.radio2.clicked.connect(self.radioButtonClicked)

        self.radio3 = QRadioButton("Delete Artwork", self)
        self.radio3.move(20, 100)
        self.radio3.clicked.connect(self.radioButtonClicked)



        self.show()

#클릭에 따라 프로그램 동작
    def radioButtonClicked(self):
        if self.radio1.isChecked():
            fname = Output_WhatKind();
        elif self.radio2.isChecked():
            fname = Input();
        elif self.radio3.isChecked():
            fname = Delete();
        self.statusBar.showMessage("고고링")


#메인
if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = Select()
    sys.exit(app.exec_())
