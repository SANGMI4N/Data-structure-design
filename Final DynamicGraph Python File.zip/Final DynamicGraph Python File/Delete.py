import sys
from PyQt5.QtCore import QCoreApplication
from PyQt5.QtWidgets import *
from Playlist_DynamicGraph import *
from Select import*

#Gui 구현
class Delete(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setupUI()

    def setupUI(self):
        self.setGeometry(515, 0, 400, 200)

        # Label
        label = QLabel("Artwork", self)
        label.move(10, 20)

        # LineEdit
        self.lineEdit = QLineEdit("", self)
        self.lineEdit.move(80, 20)

        self.pushButton1= QPushButton("Delete",self)
        self.pushButton1.move(200,20)
        self.pushButton1.clicked.connect(self.deleteArt)

        self.pushButton2= QPushButton("Not anymore", self)
        self.pushButton2.move(200,60)
        self.pushButton2.clicked.connect(QCoreApplication.instance().quit)

        # StatusBar
        self.statusBar = QStatusBar(self)
        self.setStatusBar(self.statusBar)

        self.show()

#Dynamic_graph에서 삭제 -> 삭제에 따른 edge 연결해제 ~ 파일에 저장
    def deleteArt(self):
        delnode = self.lineEdit.text()
        if delnode in n_Artist :
            n_Artist.pop(delnode)
        if delnode in n_Year :
            n_Year.pop(delnode)
        if delnode in n_Genre :
            n_Genre.pop(delnode)
        if delnode in n_Culture :
            n_Culture.pop(delnode)
        self.statusBar.showMessage(self.lineEdit.text())

        f_artist = open("f_artist.text", 'at')
        f_culture = open("f_culture.text", 'at')
        f_genre = open("f_genre.text", 'at')
        f_year = open("f_year.text", 'at')

        f_artist.write(delnode+":"+"delete"+"\n")
        f_culture.write(delnode+":"+"delete"+"\n")
        f_year.write(delnode+":"+"delete"+"\n")
        f_genre.write(delnode+":"+"delete"+"\n")

        f_artist.close
        f_culture.close
        f_genre.close
        f_year.close


'''
if __name__ == "__main__":
    app = QApplication(sys.argv)
    p_del = Delete()
    p_del.show()
    app.exec_()
'''