import sys
from _hashlib import new

from PyQt5.QtCore import QCoreApplication
from PyQt5.QtWidgets import *
from PyQt5.uic.properties import QtGui
from Playlist_DynamicGraph import *
from PyQt5.QtGui import QIcon, QPixmap


#입력에 대한 설명, 가이드라인
tistmsg = ""
for x in list(n_Artist.values()):
    tistmsg = tistmsg + " / " + str(x);
yearmsg = ""
for x in list(n_Year.values()):
    yearmsg = yearmsg + " / " + str(x);
enremsg = "drawing / performance / sculpture / architecture / etc"
cultmsg = "동양/서양"

#fir_kind = 0
se_kind = 0
kind2 = ""
a_num=0

#gui 구현 및 dynamic_graph 저장된 파일 open
class Output_WhatKind(QMainWindow):
    def __init__(self):
        super().__init__()
        self.title = 'Play'
        self.setupUI()

        f_artist = open("f_artist.text", 'rt')
        f_culture = open("f_culture.text", 'rt')
        f_genre = open("f_genre.text", 'rt')
        f_year = open("f_year.text", 'rt')

    def setupUI(self):
        self.setGeometry(800, 200, 2000, 1000)
        self.setWindowTitle(self.title)

        #gui
        self.checkBox1 = QCheckBox("Artist", self)
        self.checkBox1.resize(150, 30)
        self.checkBox1.move(10, 10)
        self.checkBox1.stateChanged.connect(self.play_intro)

        self.checkBox2 = QCheckBox("Year", self)
        self.checkBox2.move(10, 30)
        self.checkBox2.resize(150, 30)
        self.checkBox2.stateChanged.connect(self.play_intro)

        self.checkBox3 = QCheckBox("Genre", self)
        self.checkBox3.move(10, 50)
        self.checkBox3.resize(150, 30)
        self.checkBox3.stateChanged.connect(self.play_intro)

        self.checkBox4 = QCheckBox("Culture", self)
        self.checkBox4.move(10, 70)
        self.checkBox4.resize(150, 30)
        self.checkBox4.stateChanged.connect(self.play_intro)

        self.statusBar = QStatusBar(self)
        self.setStatusBar(self.statusBar)

        self.show()


#재생 intro - 재생값 입력 1
    def play_intro(self):
        if self.checkBox1.isChecked() == True:
            msg = "Artist Category : " + tistmsg
            global fir_kind
            fir_kind = 1
            self.play_final()
        if self.checkBox2.isChecked() == True:
            msg = "Year Category : " + yearmsg
            fir_kind = 2
            self.play_final()
        if self.checkBox3.isChecked() == True:
            msg = "Genre Category : " + enremsg
            fir_kind = 3
            self.play_final()
        if self.checkBox4.isChecked() == True:
            msg = "Genre Category : " + cultmsg
            fir_kind = 4
            self.play_final()

#재생 final - 재생값 입력 2
    def play_final(self):
        # Label
        label = QLabel("What do you Want to Play?", self)
        label.move(10, 100)
        label.resize(200, 30)

        # LineEdit
        self.lineEdit = QLineEdit("", self)
        self.lineEdit.move(200, 100)

        self.pushButton1 = QPushButton("Play", self)
        self.pushButton1.move(310, 100)
        self.pushButton1.clicked.connect(self.PlayOn)

        # StatusBar
        self.statusBar = QStatusBar(self)
        self.setStatusBar(self.statusBar)

        label.show()
        self.lineEdit.show()
        self.pushButton1.show()


#재생 - 입력한 edge로 연결되어 있는 작품 군집 출력
    def PlayOn(self):
        kind1 = self.lineEdit.text()
        d = 'delete'
        i=150;
        j=0
        num=0
        global a_num
        print(fir_kind)
        for x in range(0,314) :
            if num == 21:
                j += 120
                i = 150
                num = 0;
            btn1 = QPushButton("", self)
            btn1.move(20+j, 20 + i)
            btn1.clicked.connect(QCoreApplication.instance().quit)
            btn1.show()
            i += 40;
            num+=1
        if fir_kind == 1: #Artist
            i=150
            j=0
            for x, p_Artist in n_Artist.items():
                if p_Artist == d or p_Artist == d + '\n':
                    continue;
                if kind1 == "":
                    if num == 21:
                        j += 120
                        i = 150
                        num = 0;
                    self.btn1 = QPushButton(x, self)
                    self.btn1.move(20+j, 20 + i)
                    self.btn1.clicked.connect(QCoreApplication.instance().quit)
                    i += 40;
                    num+=1;
                    self.btn1.show()
                if p_Artist == kind1 or kind1 + "\n" == p_Artist:
                    if num == 21:
                        j += 120
                        i = 150
                        num = 0;
                    btn1 = QPushButton(x, self)
                    btn1.move(20+j, 20 + i)
                    btn1.clicked.connect(QCoreApplication.instance().quit)
                    i += 40;
                    num += 1;
                    btn1.show()
        if fir_kind == 2: #Year
            i=150
            j=0
            for x, p_Year in n_Year.items():
                if p_Year == d or p_Year == d + '\n':
                    continue;
                if kind1 == "":
                    if num == 21:
                        j += 120
                        i = 150
                        num = 0;
                    self.btn1 = QPushButton(x, self)
                    self.btn1.move(20+j, 20 + i)
                    self.btn1.clicked.connect(QCoreApplication.instance().quit)
                    i += 40;
                    num+=1;
                    self.btn1.show()
                elif p_Year == kind1 or kind1 + "\n" == p_Year:
                    if num == 21:
                        j += 120
                        i = 150
                        num = 0;
                    btn1 = QPushButton(x, self)
                    btn1.move(20+j, 20 + i)
                    btn1.clicked.connect(QCoreApplication.instance().quit)
                    i += 40;
                    num += 1;
                    btn1.show()
        if fir_kind == 3: #Genre
            i=150
            j=0
            for x, p_Genre in n_Genre.items():
                if p_Genre == d or p_Genre == d + '\n':
                    continue;
                if kind1 == "":
                    if num == 21:
                        j += 120
                        i = 150
                        num = 0;
                    btn1 = QPushButton(x, self)
                    btn1.move(20+j, 20 + i)
                    btn1.clicked.connect(QCoreApplication.instance().quit)
                    i += 40;
                    num += 1;
                    btn1.show()
                elif p_Genre == kind1 or kind1 + "\n" == p_Genre:
                    if num == 21:
                        j += 120
                        i = 150
                        num = 0;
                    btn1 = QPushButton(x, self)
                    btn1.move(20+j, 20 + i)
                    btn1.clicked.connect(QCoreApplication.instance().quit)
                    i += 40;
                    num += 1;
                    btn1.show()
        if fir_kind == 4: #Culture
            i=150
            j=0
            for x, p_Culture in n_Culture.items():
                if p_Culture == d or p_Culture == d + '\n':
                    continue;
                if kind1 == "":
                    if num == 21:
                        j += 120
                        i = 150
                        num = 0;
                    btn1 = QPushButton(x, self)
                    btn1.move(20+j, 20 + i)
                    btn1.clicked.connect(QCoreApplication.instance().quit)
                    i += 40;
                    num += 1;
                    btn1.show()
                elif kind1 == p_Culture or kind1 + "\n" == p_Culture:
                    if num == 21:
                        j += 120
                        i = 150
                        num = 0;
                    btn1 = QPushButton(x, self)
                    btn1.move(20+j, 20 + i)
                    btn1.clicked.connect(QCoreApplication.instance().quit)
                    i += 40;
                    num+=1;
                    btn1.show()



if __name__ == "__main__":
    app = QApplication(sys.argv)
    mywindow = Output_WhatKind()
    mywindow.show()
    app.exec_()