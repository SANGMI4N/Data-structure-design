import sys

#Dynamic Graph
#by Dictionary
#keys() : Artwork : node
#values() : Information : edge

n_Artist = {}
n_Year = {}
n_Genre = {}
n_Culture = {}

#파일 불러오기
f_artist = open("f_artist.text", 'rt')
f_culture = open("f_culture.text", 'rt')
f_genre = open("f_genre.text", 'rt')
f_year = open("f_year.text", 'rt')

#파일에 저장된 정보를 그래프에 업로드
#프로그램이 꺼졌을때도 기록된 정보들을 잃지 않기 위함
line1 = f_artist.readlines()
for str_A in line1:
    Alist = str_A.split(':')
    str_Akey = Alist[0]
    str_Avalue = Alist[1]
    n_Artist[str_Akey] = str_Avalue

line2 = f_year.readlines()
for str_Y in line2:
    Ylist=str_Y.split(':')
    str_Ykey =Ylist[0]
    str_Yvalue = Ylist[1]
    n_Year[str_Ykey] = str_Yvalue

line3 = f_genre.readlines()
for str_G in line3:
    Glist=str_G.split(':')
    str_Gkey =Glist[0]
    str_Gvalue = Glist[1]
    n_Genre[str_Gkey] = str_Gvalue

line4 = f_culture.readlines()
for str_C in line4:
    Clist=str_C.split(':')
    str_Ckey =Clist[0]
    str_Cvalue = Clist[1]
    n_Culture[str_Ckey] = str_Cvalue


