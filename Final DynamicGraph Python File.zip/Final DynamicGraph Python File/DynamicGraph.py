'''
프로그램 : smart playlist

초기화면 : 입력할지 출력할지 결정 (QCheckBox)
    1) 입력 : 정보 입력 ㅡ> node(딕셔너리.키)로 저장, edge(딕셔너리.벨류)로 연결
    2) 출력 :
        a) 어떤 특징을 갖는 작품 list를 출력할 것인지 선택
        b) 해당 특징(벨류)를 갖는 작품(키) 출력 | GUI로 구현
    3) 삭제 : 딕셔너리에서 삭

Dynamic_Graph
입력 : 작품과 정보 -> 기존에 입력된 정보값이 동일한 노드(작품)들과 연결
삭제 : 작품 -> 딕셔너리의 keys()값을 조사하며 있으면 삭제
'''


import tkinter
import sys
from PyQt5.QtWidgets import *



'''
GUI 구현 - pyqt5
ARTWORK 구현 -> 사용자의 입력값에 따라서 class 다르게 접근
->접근된 클래스에 따라 다르게 연결 - gui 구현

1. 레이아웃
2. QcheckBox -> 사용자의 선택에 따라 구동 // QInputDialog
3. 가시화 : Qgrid + 레이아웃 중첩
'''




'''
if(1):
    Artist.new=[5];
print(Artist.new)

Artist.Artwork.append(input());
print(Artist.Artwork)
D = int(input())
Artist.Artwork.remove(D);

print(Artist.Artwork)
'''

#입력값 저장이므로 상속

'''
이미지 파일 불러오기
'''

'''
도구
enumerate모듈 : 인덱스 값 표시
sorted내장함수 : 입력값 정렬후 결과값으로 리스트 반환
메타클래스 : 클래스를 만드는 클래스
'''

############################################################

'''
컨테이너(리스트) or 딕셔너리로 작품-특징
-> 특징이 같은 artwork 같은 값으로 linked (자릿수로 설정) -> gui 구현
'''

'''
이미지 파일 불러오기
'''
