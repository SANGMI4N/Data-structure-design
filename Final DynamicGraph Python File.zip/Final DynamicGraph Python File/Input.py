import sys
from PyQt5.QtCore import QCoreApplication
from PyQt5.QtWidgets import *
from Playlist_DynamicGraph import *
from Select import*

#Artwork 추가 gui
class Input(QWidget):
    def __init__(self):
        super().__init__()
        self.setupUI()

    def setupUI(self):
        self.setGeometry(515, 0, 300, 100)

        self.label1 = QLabel("Artwork ")
        self.label2 = QLabel("Artist ")
        self.label3 = QLabel("Year ")
        self.label4 = QLabel("Genre ")
        self.label5 = QLabel("Culture ")


        self.lineEdit1 = QLineEdit()
        self.lineEdit2 = QLineEdit()
        self.lineEdit3 = QLineEdit()
        self.lineEdit4 = QLineEdit()
        self.lineEdit5 = QLineEdit()
        self.pushButton1= QPushButton("Add on Playlist")
        self.pushButton1.clicked.connect(self.inputNode)
        self.pushButton2= QPushButton("Not anymore")
        self.pushButton2.clicked.connect(QCoreApplication.instance().quit)


        layout = QGridLayout()

        layout.addWidget(self.label1, 0, 0)
        layout.addWidget(self.lineEdit1, 0, 1)
        layout.addWidget(self.pushButton1, 0, 2)
        layout.addWidget(self.pushButton2, 4, 2)

        layout.addWidget(self.label2, 1, 0)
        layout.addWidget(self.lineEdit2, 1, 1)


        layout.addWidget(self.label3, 2, 0)
        layout.addWidget(self.lineEdit3, 2, 1)


        layout.addWidget(self.label4, 3, 0)
        layout.addWidget(self.lineEdit4, 3, 1)

        layout.addWidget(self.label5, 4, 0)
        layout.addWidget(self.lineEdit5, 4, 1)

        self.setLayout(layout)
        self.show()


    #Dynamic Graph 추가 - Node 연결
    #Dynamic Graph 파일_쓰기
    def inputNode(self):
        Artwork =  self.lineEdit1.text()
        Artist = self.lineEdit2.text()
        preYear = self.lineEdit3.text()
        preYear = int(int(preYear)/100*100) #100년 단위로 분류
        Year = str(preYear)
        Genre = self.lineEdit4.text()
        Culture = self.lineEdit5.text()

        n_Artist[Artwork] = Artist
        n_Year[Artwork] = Year
        n_Genre[Artwork] = Genre
        n_Culture[Artwork] = Culture

        f_artist = open("f_artist.text", 'at')
        f_culture = open("f_culture.text", 'at')
        f_genre = open("f_genre.text", 'at')
        f_year = open("f_year.text", 'at')

        f_artist.write(Artwork+':'+Artist+'\n')
        f_culture.write(Artwork+':'+Culture+'\n')
        f_genre.write(Artwork+':'+Genre+'\n')
        f_year.write(Artwork+':'+Year+'\n')




'''
app = QApplication(sys.argv)
p_input = Input()
p_input.show()
app.exec_()
'''